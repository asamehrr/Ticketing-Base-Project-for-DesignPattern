package edu.ticket;

import edu.ticket.state.TicketState;
import edu.ticket.strategy.TicketTypeStrategy;

public class Ticket {

    private TicketState state;
    private TicketTypeStrategy strategy;

    public Ticket(TicketState state, TicketTypeStrategy strategy) {
        this.state = state;
        this.strategy = strategy;
    }

    public void handle() {
        while (!(state instanceof edu.ticket.state.ClosedState)) {
            state.handle(this);
        }
        state.handle(this);
    }

    public void setState(TicketState state) {
        this.state = state;
    }

    public TicketTypeStrategy getStrategy() {
        return strategy;
    }
}