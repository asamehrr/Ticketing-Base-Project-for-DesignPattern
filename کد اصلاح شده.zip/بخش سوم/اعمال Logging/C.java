package edu.ticket.service;

import edu.ticket.Ticket;

public class TicketService {

    public void process(Ticket ticket) {
        ticket.handle();
        System.out.println("Logging ticket handling");
    }
}