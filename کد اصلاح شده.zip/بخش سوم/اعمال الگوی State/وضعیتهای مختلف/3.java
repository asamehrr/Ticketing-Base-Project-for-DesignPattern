package edu.ticket.state;

import edu.ticket.Ticket;

public class InProgressState implements TicketState {
    @Override
    public void handle(Ticket ticket) {
        System.out.println("Working on ticket");
        ticket.getStrategy().respond();
        ticket.setState(new ResolvedState());
    }
}