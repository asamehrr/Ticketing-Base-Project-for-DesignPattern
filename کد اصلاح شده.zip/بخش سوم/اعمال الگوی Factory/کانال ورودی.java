package edu.ticket.factory;

import edu.ticket.Ticket;
import edu.ticket.state.NewState;
import edu.ticket.strategy.BugTicketStrategy;
import edu.ticket.strategy.QuestionTicketStrategy;
import edu.ticket.strategy.TicketTypeStrategy;

public class TicketFactory {

    public static Ticket createTicket(String channel, String type) {

        if (channel.equals("WEB")) {
            System.out.println("Received from web");
        } else if (channel.equals("EMAIL")) {
            System.out.println("Received from email");
        }

        TicketTypeStrategy strategy;

        if (type.equals("BUG")) {
            strategy = new BugTicketStrategy();
        } else {
            strategy = new QuestionTicketStrategy();
        }

        return new Ticket(new NewState(), strategy);
    }
}