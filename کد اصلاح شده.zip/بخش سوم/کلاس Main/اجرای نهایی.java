import edu.ticket.Ticket;
import edu.ticket.factory.TicketFactory;
import edu.ticket.service.TicketService;

public class Main {

    public static void main(String[] args) {

        TicketService service = new TicketService();

        Ticket t1 = TicketFactory.createTicket("WEB", "BUG");
        service.process(t1);

        System.out.println("------------");

        Ticket t2 = TicketFactory.createTicket("EMAIL", "QUESTION");
        service.process(t2);
    }
}