package edu.ticket.strategy;

public interface TicketTypeStrategy {
    void assign();
    void respond();
}